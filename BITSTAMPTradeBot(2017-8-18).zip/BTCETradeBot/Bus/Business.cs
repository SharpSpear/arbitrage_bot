﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTCETradeBot
{
    public class Business
    {
        public static string GetDonationAddress()
        {
            return "3P8wbn5HpFVncoG6ksgqB2b6imNqjepvkC";
        }
    }
}
